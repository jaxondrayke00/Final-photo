CartoonBooth Pro — project files will be regenerated here if missing.
